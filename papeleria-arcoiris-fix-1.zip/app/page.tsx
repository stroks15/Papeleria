import Header from '@/components/Header';
import TramiteCard from '@/components/TramiteCard';
import BottomNav from '@/components/BottomNav';
import Assistant from '@/components/Assistant';
import { tramites } from '@/lib/tramites';

export default function Home() {
  return (
    <main className="min-h-screen pb-28">
      <Header subtitulo="Hola, te ayudamos a realizar tus trámites fácil y rápido" />
      <section className="flex flex-col gap-3 px-5">
        {tramites.map((tramite) => (
          <TramiteCard key={tramite.slug} tramite={tramite} />
        ))}
      </section>
      <p className="mt-6 px-5 text-center text-sm text-tinta-suave">
        No solo imprimimos documentos: te acompañamos a hacer tus trámites digitales.
      </p>
      <Assistant modo="inicio" />
      <BottomNav />
    </main>
  );
}
